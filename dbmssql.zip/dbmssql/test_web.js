var db = require('./dbhelper');
var express = require('express');
var app = express();
var arr = [];
// 查询实例
db.query('SELECT * FROM websites', [], function(result, fields) {
    app.get('/select', function(req, res) {
        res.send(result);
    });
});
app.listen(3001);