// 配置链接数据库参数
module.exports = {
    host: '127.0.0.1',
    port: 1433, // 端口号
    database: '365College', // 数据库名
    user: 'sa', // 数据库用户名
    password: 'qwe123456' // 数据库密码
};