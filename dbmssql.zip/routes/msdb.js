//链接数据库
var sqlserver = require('mssql');

var msdb = {};
var dbConfig = {
	server: "127.0.0.1",
	database: "dbnode",
	user: "sa",
	password: "qwe123456",
	port: 1433
};

var db = function(sql, params, callback) {
	sqlserver.close();
	sqlserver.connect(dbConfig).then(function() {
		var req = new sqlserver.Request().query(sql, params).then(function(results, fields) {
				// 将查询出来的数据返回给回调函数
				console.log(results);
				callback && callback(results, fields);
				// results作为数据操作后的结果，fields作为数据库连接的一些字段
				// 停止链接数据库，必须再查询语句后，要不然一调用这个方法，就直接停止链接，数据操作就会失败
				sqlserver.close(function(err) {
						if(err) {
							console.log('关闭数据库连接失败！');
							throw err;
						}
					})
					.catch(function(err) {
						console.log(err);
						sqlserver.close();
					});
			})
			.catch(function(err) {
				callback && callback(err,1);
				sqlserver.close();
			});

	})
};

module.exports = db;