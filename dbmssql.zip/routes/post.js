var express = require('express');
var router = express.Router();
var db = require('./msdb.js');
/* GET home page. */
router.post('/', function(req, res, next) {
  var sql ="INSERT INTO tabname(name,age) VALUES('凤飞飞','15')"
	var params=[];
	db(sql,params , function(doc,status) {
		if(status==1) {
			res.end({
				status: 1,
				msg: doc
			});

		} else {
			res.json({
				status: 0,
				msg: '',
				result: {
					count: doc.length,
					list: doc.recordset
				}
			})
		}

	})
});

module.exports = router;
