var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.send("hello ,node.js");
});
router.get('/aa', function(req, res, next) {
  res.send("aa ,node.js");
});
router.get('/aak', function(req, res, next) {
  res.send("aa ,node.js");
});
module.exports = router;
