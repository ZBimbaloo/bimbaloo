var express = require('express');
var db = require('./db.js');
var moment = require('moment');
var router = express.Router();

/* GET home page. */
router.get('/', function (req, res, next) {
    db.selectAll('tabname', function (err, doc) {//查询所有news表的数据
        if(err) {
			res.end({
				status: 1,
				msg: err
			});

		} else {
			res.json({
				status: 0,
				msg: '',
				result: {
					count: doc.length,
					list: doc.recordset
				}
			})
		}
    });
});
router.get('/delete/:id', function (req, res, next) {//删除一条id对应的news表的数据
    var id = req.params.id;
    db.del("where id = @id", {id:id}, "tabname", function(err, result){
        res.redirect('back');//返回前一个页面
    });
});
router.post('/update/:id', function (req, res, next) {//更新一条对应id的news表的数据
    var id = req.params.id;
    var content = req.body;
    db.update(content, {id:id}, "tabname", function(err, doc){
        if(err) {
			res.end({
				status: 1,
				msg: err
			});

		} else {
			res.json({
				status: 0,
				msg: '',
				result: {
					count: doc.length,
					list: doc.recordset
				}
			})
		}
    });
});
router.post('/add', function (req, res, next) {//更新一条对应id的news表的数据
    var id = req.params.id;
    var content = req.body;
    db.add(content, "tabname", function(err, doc){
        if(err) {
			res.end({
				status: 1,
				msg: err
			});

		} else {
			res.json({
				status: 0,
				msg: '',
				result: {
					count: doc.length,
					list: doc.recordset
				}
			})
		}
    });
});

module.exports = router;