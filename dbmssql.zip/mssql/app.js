var express = require('express');
var app = express();
var bodyParser = require('body-parser');//引入中间件req.body(获取post的数据)
var indexRouter = require('./index.js');
// 允许跨域
app.all('*', function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Content-Type,Content-Length, Authorization, Accept,X-Requested-With");
    res.header("Access-Control-Allow-Methods","PUT,POST,GET,DELETE,OPTIONS");
    res.header("X-Powered-By",' 3.2.1')
    if(req.method=="OPTIONS") res.send(200);/*让options请求快速返回*/
    else  next();

});
var server = app.listen(8018, function() {
	var host = server.address().address
	var port = server.address().port
	console.log("应用实例，访问地址为 http://%s:%s", host, port)
})
app.use(bodyParser.urlencoded({ extended: true }))//引入中间件req.body(获取post的数据)float返回数据[]{}
app.use(bodyParser.json())//引入中间件req.body(获取post的数据)
app.use('/', indexRouter);
